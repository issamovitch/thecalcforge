// ============================================================================
// CalcForge - Tax Engine Comprehensive Test Suite
// ============================================================================

import { describe, it, expect } from "bun:test";
import { calculateFederalTax, calculateFICA } from "../lib/tax/federal";
import { calculatePaycheck } from "../lib/tax/index";
import { californiaCalculator } from "../lib/tax/states/california";
import { texasCalculator } from "../lib/tax/states/texas";
import { floridaCalculator } from "../lib/tax/states/florida";
import { newYorkCalculator } from "../lib/tax/states/new-york";
import { pennsylvaniaCalculator } from "../lib/tax/states/pennsylvania";
import { stateTaxConfig as caConfig } from "../../content/paycheck/california/data";
import { stateTaxConfig as txConfig } from "../../content/paycheck/texas/data";
import { stateTaxConfig as flConfig } from "../../content/paycheck/florida/data";
import { stateTaxConfig as nyConfig } from "../../content/paycheck/new-york/data";
import { stateTaxConfig as paConfig } from "../../content/paycheck/pennsylvania/data";
import type { CalculatorInput } from "../types/calculator";

// ============================================================================
// Helper: standard single $60k input with zero deductions
// ============================================================================

function makeInput(overrides: Partial<CalculatorInput> = {}): CalculatorInput {
  return {
    grossPay: 60000,
    payFrequency: "annual" as const,
    filingStatus: "single" as const,
    retirement401kPercent: 0,
    retirement401kType: "percent" as const,
    retirement401kFixed: 0,
    hsaContribution: 0,
    otherPreTax: 0,
    postTaxDeductions: 0,
    ...overrides,
  };
}

// ============================================================================
// 1. Federal Tax — Single Filer $60,000
// ============================================================================
// Federal standard deduction (single, 2026 — IRS Rev. Proc. 2025-32): $16,100
// Taxable income: $60,000 - $16,100 = $43,900
// Brackets (single, 2026):
//   10% on $0 – $12,400          = $1,240.00
//   12% on $12,400 – $43,900     = $31,500 × 0.12 = $3,780.00
// Total federal tax = $5,020.00

describe("Federal Tax", () => {
  it("calculates federal tax for single filer with $43,900 taxable income", () => {
    const result = calculateFederalTax(43900, "single");
    expect(result.tax).toBeCloseTo(5020, 0);
  });

  it("has correct marginal rate of 12% for $43,900 taxable income", () => {
    const result = calculateFederalTax(43900, "single");
    expect(result.marginalRate).toBe(0.12);
  });

  it("produces correct breakdown lines for $43,900 taxable income", () => {
    const result = calculateFederalTax(43900, "single");
    expect(result.breakdownLines).toHaveLength(2);
    expect(result.breakdownLines[0].amount).toBeCloseTo(1240, 0);
    expect(result.breakdownLines[1].amount).toBeCloseTo(3780, 0);
  });
});

// ============================================================================
// 2. FICA for $60,000 Single
// ============================================================================
// SS: 6.2% × $60,000 = $3,720.00 (under $176,100 wage base)
// Medicare: 1.45% × $60,000 = $870.00
// Additional Medicare: $0 (under $200,000 threshold)
// Total FICA: $4,590.00

describe("FICA", () => {
  it("calculates Social Security tax for $60,000", () => {
    const result = calculateFICA(60000, "single");
    expect(result.socialSecurity).toBeCloseTo(3720, 0);
  });

  it("calculates Medicare tax for $60,000", () => {
    const result = calculateFICA(60000, "single");
    expect(result.medicare).toBeCloseTo(870, 0);
  });

  it("has zero Additional Medicare for $60,000 single", () => {
    const result = calculateFICA(60000, "single");
    expect(result.medicareAdditional).toBe(0);
  });

  it("has correct total FICA of $4,590 for $60,000 single", () => {
    const result = calculateFICA(60000, "single");
    const totalFica = result.socialSecurity + result.medicare + result.medicareAdditional;
    expect(totalFica).toBeCloseTo(4590, 0);
  });
});

// ============================================================================
// 3. California State Tax for $60,000 Single
// ============================================================================
// CA standard deduction (single, FTB 2025 — latest official): $5,706
// CA taxable income: $60,000 - $5,706 = $54,294
// CA brackets (single) from FTB 2025 Schedule X:
//   1.0%  on $0 – $11,079         = $110.79
//   2.0%  on $11,079 – $26,264    = $15,185 × 0.02 = $303.70
//   4.0%  on $26,264 – $41,452    = $15,188 × 0.04 = $607.52
//   6.0%  on $41,452 – $54,294    = $12,842 × 0.06 = $770.52
// CA income tax = $1,792.53
// SDI: 1.3% × $60,000 = $780.00 (no wage cap since 2024, SB 951)
// Total CA tax = $2,572.53

describe("California State Tax", () => {
  it("returns positive state tax for $60,000 single", () => {
    const result = californiaCalculator.calculateStateTax(60000, "single", {});
    expect(result.tax).toBeGreaterThan(0);
  });

  it("includes SDI in the breakdown", () => {
    const result = californiaCalculator.calculateStateTax(60000, "single", {});
    const hasSdi = result.breakdownLines.some((line) => line.label.includes("SDI"));
    expect(hasSdi).toBe(true);
  });

  it("calculates total state tax close to $2,573", () => {
    const result = californiaCalculator.calculateStateTax(60000, "single", {});
    expect(result.tax).toBeCloseTo(2572.53, 0);
  });

  it("has correct marginal rate of 6% for $60,000 single", () => {
    const result = californiaCalculator.calculateStateTax(60000, "single", {});
    expect(result.marginalRate).toBe(0.06);
  });
});

// ============================================================================
// 4. Texas State Tax for $60,000 Single — No Income Tax
// ============================================================================

describe("Texas State Tax", () => {
  it("returns exactly 0 state tax for $60,000 single", () => {
    const result = texasCalculator.calculateStateTax(60000, "single", {});
    expect(result.tax).toBe(0);
  });

  it("returns zero marginal rate", () => {
    const result = texasCalculator.calculateStateTax(60000, "single", {});
    expect(result.marginalRate).toBe(0);
  });
});

// ============================================================================
// 5. Florida State Tax for $60,000 Single — No Income Tax
// ============================================================================

describe("Florida State Tax", () => {
  it("returns exactly 0 state tax for $60,000 single", () => {
    const result = floridaCalculator.calculateStateTax(60000, "single", {});
    expect(result.tax).toBe(0);
  });

  it("returns zero marginal rate", () => {
    const result = floridaCalculator.calculateStateTax(60000, "single", {});
    expect(result.marginalRate).toBe(0);
  });
});

// ============================================================================
// 6. New York State Tax for $60,000 Single
// ============================================================================
// NY standard deduction (single): $8,000
// NY taxable income: $60,000 - $8,000 = $52,000
// NY brackets (single) from new-york.ts:
//   4.0%   on $0 – $8,500          = $340.00
//   4.5%   on $8,500 – $11,700     = $3,200 × 0.045 = $144.00
//   5.25%  on $11,700 – $13,900    = $2,200 × 0.0525 = $115.50
//   5.5%   on $13,900 – $52,000    = $38,100 × 0.055 = $2,095.50
// NY state tax (no NYC) = $2,695.00
//
// NYC tax on $52,000 taxable income:
//   3.078% on $0 – $12,000         = $369.36
//   3.876% on $12,000 – $25,000    = $13,000 × 0.03876 = $503.88
//   3.819% on $25,000 – $50,000    = $25,000 × 0.03819 = $954.75
//   3.876% on $50,000 – $52,000    = $2,000 × 0.03876 = $77.52
// NYC tax = $1,905.51
// Total with NYC = $2,695 + $1,905.51 = $4,600.51

describe("New York State Tax", () => {
  it("returns positive state tax for $60,000 single without NYC", () => {
    const result = newYorkCalculator.calculateStateTax(60000, "single", {});
    expect(result.tax).toBeGreaterThan(0);
  });

  it("calculates state-only tax close to $2,695 without NYC", () => {
    const result = newYorkCalculator.calculateStateTax(60000, "single", {});
    expect(result.tax).toBeCloseTo(2695, 0);
  });

  it("calculates higher tax with NYC resident flag", () => {
    const withoutNyc = newYorkCalculator.calculateStateTax(60000, "single", {});
    const withNyc = newYorkCalculator.calculateStateTax(60000, "single", {
      nycResident: true,
    });
    expect(withNyc.tax).toBeGreaterThan(withoutNyc.tax);
  });

  it("includes NYC Tax lines in breakdown when nycResident is true", () => {
    const result = newYorkCalculator.calculateStateTax(60000, "single", {
      nycResident: true,
    });
    const hasNycTax = result.breakdownLines.some((line) =>
      line.label.includes("NYC Tax:")
    );
    expect(hasNycTax).toBe(true);
  });

  it("calculates total tax close to $4,601 with NYC resident", () => {
    const result = newYorkCalculator.calculateStateTax(60000, "single", {
      nycResident: true,
    });
    expect(result.tax).toBeCloseTo(4601, 0);
  });
});

// ============================================================================
// 7. Pennsylvania State Tax for $60,000 Single
// ============================================================================
// PA flat rate: 3.07% × $60,000 = $1,842.00
// Local EIT: 1.0% × $60,000 = $600.00
// Total = $2,442.00

describe("Pennsylvania State Tax", () => {
  it("calculates flat 3.07% state tax of $1,842", () => {
    const result = pennsylvaniaCalculator.calculateStateTax(60000, "single", {
      paLocalEitRate: 0.01,
    });
    // Total includes local, but state portion alone is $1,842
    // We verify the total is correct
    expect(result.tax).toBeCloseTo(2442, 0);
  });

  it("adds $600 local EIT at 1% rate", () => {
    const result = pennsylvaniaCalculator.calculateStateTax(60000, "single", {
      paLocalEitRate: 0.01,
    });
    const localEitLine = result.breakdownLines.find((line) =>
      line.label.includes("Local EIT")
    );
    expect(localEitLine).toBeDefined();
    expect(localEitLine!.amount).toBeCloseTo(600, 0);
  });

  it("has marginal rate of 4.07% (3.07% state + 1% local)", () => {
    const result = pennsylvaniaCalculator.calculateStateTax(60000, "single", {
      paLocalEitRate: 0.01,
    });
    expect(result.marginalRate).toBeCloseTo(0.0407, 4);
  });

  it("returns 0 local EIT when rate is 0", () => {
    const result = pennsylvaniaCalculator.calculateStateTax(60000, "single", {
      paLocalEitRate: 0,
    });
    // State tax only, no local
    expect(result.tax).toBeCloseTo(1842, 0);
    const localEitLine = result.breakdownLines.find((line) =>
      line.label.includes("Local EIT")
    );
    // When localTax is 0, the PA calculator still pushes the line
    // Actually, it checks `if (localTax > 0)` so with rate 0, no line
    expect(localEitLine).toBeUndefined();
  });
});

// ============================================================================
// 8. Full Paycheck Calculation — Integration Tests for All 5 States
// ============================================================================
// For all states: grossPay=60000, payFrequency="annual", filingStatus="single",
// all deductions = 0
//
// Federal tax = $5,084, SS = $3,720, Medicare = $870, Add Medicare = $0
// FICA total = $4,590
//
// Per-state expected annual take-home (approximate):
//   CA: 60000 - 5084 - 3720 - 870 - 2630 = $47,696
//   TX: 60000 - 5084 - 3720 - 870 - 0    = $50,326
//   FL: 60000 - 5084 - 3720 - 870 - 0    = $50,326
//   NY: 60000 - 5084 - 3720 - 870 - 2695  = $47,631
//   PA: 60000 - 5084 - 3720 - 870 - 2442  = $47,884

describe("Full Paycheck Calculation — Integration", () => {
  const baseInput = makeInput();

  it("California: take-home > 0 and < gross", () => {
    const result = calculatePaycheck(baseInput, caConfig);
    expect(result.annual.takeHomePay).toBeGreaterThan(0);
    expect(result.annual.takeHomePay).toBeLessThan(60000);
    expect(result.annual.takeHomePay).toBeCloseTo(47696, 0);
  });

  it("Texas: take-home > 0 and < gross", () => {
    const result = calculatePaycheck(baseInput, txConfig);
    expect(result.annual.takeHomePay).toBeGreaterThan(0);
    expect(result.annual.takeHomePay).toBeLessThan(60000);
    expect(result.annual.takeHomePay).toBeCloseTo(50326, 0);
  });

  it("Florida: take-home > 0 and < gross", () => {
    const result = calculatePaycheck(baseInput, flConfig);
    expect(result.annual.takeHomePay).toBeGreaterThan(0);
    expect(result.annual.takeHomePay).toBeLessThan(60000);
    expect(result.annual.takeHomePay).toBeCloseTo(50326, 0);
  });

  it("New York: take-home > 0 and < gross", () => {
    const result = calculatePaycheck(baseInput, nyConfig);
    expect(result.annual.takeHomePay).toBeGreaterThan(0);
    expect(result.annual.takeHomePay).toBeLessThan(60000);
    expect(result.annual.takeHomePay).toBeCloseTo(47631, 0);
  });

  it("Pennsylvania: take-home > 0 and < gross", () => {
    const result = calculatePaycheck(baseInput, paConfig);
    expect(result.annual.takeHomePay).toBeGreaterThan(0);
    expect(result.annual.takeHomePay).toBeLessThan(60000);
    expect(result.annual.takeHomePay).toBeCloseTo(47884, 0);
  });

  it("TX and FL take-home is significantly higher than CA", () => {
    const caResult = calculatePaycheck(baseInput, caConfig);
    const txResult = calculatePaycheck(baseInput, txConfig);
    const flResult = calculatePaycheck(baseInput, flConfig);

    // TX and FL should be at least $2,000 more than CA
    const caDiff = txResult.annual.takeHomePay - caResult.annual.takeHomePay;
    const flDiff = flResult.annual.takeHomePay - caResult.annual.takeHomePay;
    expect(caDiff).toBeGreaterThan(2000);
    expect(flDiff).toBeGreaterThan(2000);
  });

  it("TX and FL take-home are nearly identical (both no state tax)", () => {
    const txResult = calculatePaycheck(baseInput, txConfig);
    const flResult = calculatePaycheck(baseInput, flConfig);
    expect(txResult.annual.takeHomePay).toBe(flResult.annual.takeHomePay);
  });

  it("all states have correct federal tax of $5,084", () => {
    const states = [caConfig, txConfig, flConfig, nyConfig, paConfig];
    for (const state of states) {
      const result = calculatePaycheck(baseInput, state);
      expect(result.annual.federalTax).toBeCloseTo(5084, 0);
    }
  });

  it("all states have correct FICA: SS=$3,720, Medicare=$870", () => {
    const states = [caConfig, txConfig, flConfig, nyConfig, paConfig];
    for (const state of states) {
      const result = calculatePaycheck(baseInput, state);
      expect(result.annual.socialSecurity).toBeCloseTo(3720, 0);
      expect(result.annual.medicare).toBeCloseTo(870, 0);
      expect(result.annual.medicareAdditional).toBe(0);
    }
  });
});

// ============================================================================
// 9. Edge Cases
// ============================================================================

describe("Edge Cases", () => {
  it("$0 income → $0 taxes and $0 take-home", () => {
    const input = makeInput({ grossPay: 0 });
    const states = [caConfig, txConfig, flConfig, nyConfig, paConfig];

    for (const state of states) {
      const result = calculatePaycheck(input, state);
      expect(result.annual.federalTax).toBe(0);
      expect(result.annual.socialSecurity).toBe(0);
      expect(result.annual.medicare).toBe(0);
      expect(result.annual.medicareAdditional).toBe(0);
      expect(result.annual.stateTax).toBe(0);
      expect(result.annual.takeHomePay).toBe(0);
      expect(result.annual.effectiveTaxRate).toBe(0);
    }
  });

  it("$1,000,000 income hits all 7 federal brackets (marginal = 37%)", () => {
    const input = makeInput({ grossPay: 1000000 });
    const result = calculatePaycheck(input, txConfig); // TX for cleanest view

    // Federal marginal should be 37% (highest bracket)
    expect(result.marginalInfo.federal).toBe(0.37);

    // Federal tax should be substantial
    // Taxable: $1,000,000 - $15,700 = $984,300
    // Expected: ~$322,379
    expect(result.annual.federalTax).toBeCloseTo(322379, -2); // within $100

    // Take-home should be positive but much less than gross
    expect(result.annual.takeHomePay).toBeGreaterThan(0);
    expect(result.annual.takeHomePay).toBeLessThan(1000000);
  });

  it("$1,000,000 income in CA hits top CA bracket (marginal = 12.3%)", () => {
    const input = makeInput({ grossPay: 1000000 });
    const result = calculatePaycheck(input, caConfig);

    // CA marginal should be 12.3% (9th bracket, since taxable $994,438 < $1M threshold for 13.3%)
    expect(result.marginalInfo.state).toBe(0.123);

    // State tax should be substantial
    expect(result.annual.stateTax).toBeGreaterThan(50000);
  });

  it("bi-weekly per-period amounts = annual / 26", () => {
    // Calculate with annual frequency
    const annualInput = makeInput({ payFrequency: "annual", grossPay: 60000 });
    const annualResult = calculatePaycheck(annualInput, txConfig);

    // Calculate with bi-weekly frequency (same annual equivalent)
    const biWeeklyGross = 60000 / 26;
    const biWeeklyInput = makeInput({
      payFrequency: "bi_weekly",
      grossPay: biWeeklyGross,
    });
    const biWeeklyResult = calculatePaycheck(biWeeklyInput, txConfig);

    // Annual figures should match
    expect(biWeeklyResult.annual.takeHomePay).toBeCloseTo(
      annualResult.annual.takeHomePay,
      0
    );
    expect(biWeeklyResult.annual.grossPay).toBeCloseTo(
      annualResult.annual.grossPay,
      0
    );

    // Per-period take-home should be annual / 26
    expect(biWeeklyResult.perPeriod.takeHomePay).toBeCloseTo(
      annualResult.annual.takeHomePay / 26,
      0
    );

    // Per-period gross should be annual / 26
    expect(biWeeklyResult.perPeriod.grossPay).toBeCloseTo(
      annualResult.annual.grossPay / 26,
      0
    );
  });

  it("FICA is capped at SS wage base for high income", () => {
    const input = makeInput({ grossPay: 500000 });
    const result = calculatePaycheck(input, txConfig);

    // SS should be capped at wage base: $176,100 × 6.2% = $10,918.20
    expect(result.annual.socialSecurity).toBeCloseTo(10918, 0);

    // Medicare should be uncapped: $500,000 × 1.45% = $7,250
    expect(result.annual.medicare).toBeCloseTo(7250, 0);

    // Additional Medicare should kick in: ($500,000 - $200,000) × 0.9% = $2,700
    expect(result.annual.medicareAdditional).toBeCloseTo(2700, 0);
  });
});

// ============================================================================
// 10. Effective Tax Rate Calculation
// ============================================================================

describe("Effective Tax Rate", () => {
  it("California $60,000 single: effective rate between 15% and 25%", () => {
    const input = makeInput();
    const result = calculatePaycheck(input, caConfig);
    const rate = result.annual.effectiveTaxRate;
    expect(rate).toBeGreaterThan(0.15);
    expect(rate).toBeLessThan(0.25);
  });

  it("Texas $60,000 single: effective rate between 15% and 18% (federal + FICA only)", () => {
    const input = makeInput();
    const result = calculatePaycheck(input, txConfig);
    const rate = result.annual.effectiveTaxRate;
    // Federal $5,084 + FICA $4,590 = $9,674 / $60,000 = 16.12%
    expect(rate).toBeGreaterThan(0.15);
    expect(rate).toBeLessThan(0.18);
  });

  it("New York $60,000 single: effective rate between 15% and 25%", () => {
    const input = makeInput();
    const result = calculatePaycheck(input, nyConfig);
    const rate = result.annual.effectiveTaxRate;
    expect(rate).toBeGreaterThan(0.15);
    expect(rate).toBeLessThan(0.25);
  });

  it("Pennsylvania $60,000 single: effective rate between 15% and 25%", () => {
    const input = makeInput();
    const result = calculatePaycheck(input, paConfig);
    const rate = result.annual.effectiveTaxRate;
    expect(rate).toBeGreaterThan(0.15);
    expect(rate).toBeLessThan(0.25);
  });

  it("effective rate is 0 for $0 income", () => {
    const input = makeInput({ grossPay: 0 });
    const result = calculatePaycheck(input, txConfig);
    expect(result.annual.effectiveTaxRate).toBe(0);
  });

  it("higher income has higher effective rate", () => {
    const lowInput = makeInput({ grossPay: 30000 });
    const highInput = makeInput({ grossPay: 200000 });
    const lowResult = calculatePaycheck(lowInput, caConfig);
    const highResult = calculatePaycheck(highInput, caConfig);
    expect(highResult.annual.effectiveTaxRate).toBeGreaterThan(
      lowResult.annual.effectiveTaxRate
    );
  });
});