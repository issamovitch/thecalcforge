// ============================================================================
// CalcForge - California State Tax Calculator (2026)
// ============================================================================

import type {
  FilingStatus,
  StateTaxCalculator,
  StateTaxResult,
  StateTaxOptions,
  TaxBracket,
  TaxBreakdownLine,
  StandardDeductions,
} from "@/types/calculator";

// ============================================================================
// 2026 California Tax Configuration
// ============================================================================

// Source: California FTB, 2025 tax year (latest official — FTB publishes 2026
// CCPI-indexed figures in late 2026; update then). Verified July 2026.
// Note: CA HOH standard deduction equals the MFJ amount, unlike federal.
const CA_STANDARD_DEDUCTION: StandardDeductions = {
  single: 5_706,
  married_filing_jointly: 11_412,
  head_of_household: 11_412,
};

// Source: 2025 California Tax Rate Schedules, FTB Schedule X (ftb.ca.gov).
// Latest official figures; FTB publishes 2026 indexed brackets in late 2026.
// The 13.3% top rate = 12.3% bracket + 1% Mental Health Services Tax over $1M,
// which is applied separately below (not a bracket).
const CA_BRACKETS_SINGLE: TaxBracket[] = [
  { rate: 0.01, min: 0, max: 11_079 },
  { rate: 0.02, min: 11_079, max: 26_264 },
  { rate: 0.04, min: 26_264, max: 41_452 },
  { rate: 0.06, min: 41_452, max: 57_542 },
  { rate: 0.08, min: 57_542, max: 72_724 },
  { rate: 0.093, min: 72_724, max: 371_479 },
  { rate: 0.103, min: 371_479, max: 445_771 },
  { rate: 0.113, min: 445_771, max: 742_953 },
  { rate: 0.123, min: 742_953, max: null },
];

// Source: 2025 California Tax Rate Schedules, FTB Schedule Y (ftb.ca.gov).
const CA_BRACKETS_MFJ: TaxBracket[] = [
  { rate: 0.01, min: 0, max: 22_158 },
  { rate: 0.02, min: 22_158, max: 52_528 },
  { rate: 0.04, min: 52_528, max: 82_904 },
  { rate: 0.06, min: 82_904, max: 115_084 },
  { rate: 0.08, min: 115_084, max: 145_448 },
  { rate: 0.093, min: 145_448, max: 742_958 },
  { rate: 0.103, min: 742_958, max: 891_542 },
  { rate: 0.113, min: 891_542, max: 1_485_906 },
  { rate: 0.123, min: 1_485_906, max: null },
];

// Source: 2025 California Tax Rate Schedules, FTB Schedule Z (ftb.ca.gov).
const CA_BRACKETS_HOH: TaxBracket[] = [
  { rate: 0.01, min: 0, max: 22_173 },
  { rate: 0.02, min: 22_173, max: 52_530 },
  { rate: 0.04, min: 52_530, max: 67_716 },
  { rate: 0.06, min: 67_716, max: 83_805 },
  { rate: 0.08, min: 83_805, max: 98_990 },
  { rate: 0.093, min: 98_990, max: 505_208 },
  { rate: 0.103, min: 505_208, max: 606_251 },
  { rate: 0.113, min: 606_251, max: 1_010_417 },
  { rate: 0.123, min: 1_010_417, max: null },
];

const CA_BRACKETS: Record<FilingStatus, TaxBracket[]> = {
  single: CA_BRACKETS_SINGLE,
  married_filing_jointly: CA_BRACKETS_MFJ,
  head_of_household: CA_BRACKETS_HOH,
};

// Source: California EDD, 2026 contribution rates (edd.ca.gov). Verified July 2026.
// SB 951 removed the SDI taxable wage cap effective Jan 1, 2024 — SDI applies to ALL wages.
const CA_SDI_RATE = 0.013; // 1.3% for 2026 (was 1.2% in 2025)

// Prop 63 (2004); threshold is statutory, not indexed. Applies to taxable income over $1M.
/** California Mental Health Services Tax (Behavioral Health Services Tax) */
const CA_MENTAL_HEALTH_RATE = 0.01; // 1%
const CA_MENTAL_HEALTH_THRESHOLD = 1_000_000;

// ============================================================================
// Progressive Bracket Helper
// ============================================================================

function calculateProgressiveTax(
  taxableIncome: number,
  brackets: TaxBracket[]
): { tax: number; breakdownLines: TaxBreakdownLine[]; marginalRate: number } {
  let remainingIncome = Math.max(0, taxableIncome);
  let totalTax = 0;
  const breakdownLines: TaxBreakdownLine[] = [];
  let marginalRate = 0;

  for (const bracket of brackets) {
    if (remainingIncome <= 0) break;

    const bracketWidth =
      bracket.max !== null ? bracket.max - bracket.min : Infinity;
    const taxableInBracket = Math.min(remainingIncome, bracketWidth);
    const taxInBracket = taxableInBracket * bracket.rate;

    if (taxableInBracket > 0) {
      totalTax += taxInBracket;
      marginalRate = bracket.rate;

      const bracketMinFormatted = bracket.min.toLocaleString("en-US");
      const bracketMaxFormatted =
        bracket.max !== null ? bracket.max.toLocaleString("en-US") : "+";

      breakdownLines.push({
        label: `${(bracket.rate * 100).toFixed(1)}% ($${bracketMinFormatted} – $${bracketMaxFormatted})`,
        amount: Math.round(taxInBracket * 100) / 100,
        rate: bracket.rate,
      });

      remainingIncome -= taxableInBracket;
    }
  }

  return {
    tax: Math.round(totalTax * 100) / 100,
    breakdownLines,
    marginalRate,
  };
}

// ============================================================================
// California State Tax Calculator
// ============================================================================

export const californiaCalculator: StateTaxCalculator = {
  calculateStateTax(
    annualGrossWages: number,
    filingStatus: FilingStatus,
    _options: StateTaxOptions
  ): StateTaxResult {
    const breakdownLines: TaxBreakdownLine[] = [];
    let totalTax = 0;
    let marginalRate = 0;

    // 1. Standard deduction
    const standardDeduction = CA_STANDARD_DEDUCTION[filingStatus];

    breakdownLines.push({
      label: "Standard Deduction",
      amount: -standardDeduction,
    });

    // 2. State income tax on taxable income
    const taxableIncome = Math.max(0, annualGrossWages - standardDeduction);
    const incomeTaxResult = calculateProgressiveTax(
      taxableIncome,
      CA_BRACKETS[filingStatus]
    );

    for (const line of incomeTaxResult.breakdownLines) {
      breakdownLines.push({
        label: `CA Income Tax: ${line.label}`,
        amount: line.amount,
        rate: line.rate,
      });
    }

    totalTax += incomeTaxResult.tax;
    marginalRate = incomeTaxResult.marginalRate;

    // 3. SDI (State Disability Insurance) — applies to ALL wages, no cap since 2024 (SB 951)
    const sdiTax = Math.round(annualGrossWages * CA_SDI_RATE * 100) / 100;

    if (sdiTax > 0) {
      breakdownLines.push({
        label: `CA SDI (${(CA_SDI_RATE * 100).toFixed(1)}% of all wages, no cap)`,
        amount: sdiTax,
        rate: CA_SDI_RATE,
      });
      totalTax += sdiTax;
    }

    // 4. Mental Health Services Tax (1% on income over $1M)
    if (annualGrossWages > CA_MENTAL_HEALTH_THRESHOLD) {
      const mentalHealthTaxable = annualGrossWages - CA_MENTAL_HEALTH_THRESHOLD;
      const mentalHealthTax = Math.round(mentalHealthTaxable * CA_MENTAL_HEALTH_RATE * 100) / 100;

      breakdownLines.push({
        label: `Mental Health Services Tax (${(CA_MENTAL_HEALTH_RATE * 100).toFixed(0)}% over $${CA_MENTAL_HEALTH_THRESHOLD.toLocaleString("en-US")})`,
        amount: mentalHealthTax,
        rate: CA_MENTAL_HEALTH_RATE,
      });

      totalTax += mentalHealthTax;
      // Mental health tax is on top of the income tax brackets, so marginal rate is the max
      marginalRate = Math.max(marginalRate, CA_MENTAL_HEALTH_RATE + incomeTaxResult.marginalRate);
    }

    const effectiveRate =
      annualGrossWages > 0
        ? Math.round((totalTax / annualGrossWages) * 10000) / 10000
        : 0;

    return {
      tax: Math.round(totalTax * 100) / 100,
      breakdownLines,
      effectiveRate,
      marginalRate,
    };
  },
};