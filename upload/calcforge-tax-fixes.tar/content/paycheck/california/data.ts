import type { StateTaxConfig } from "@/types/calculator";

export const stateTaxConfig: StateTaxConfig = {
  slug: "california",
  name: "California",
  abbreviation: "CA",
  year: 2026,
  meta: {
    title:
      "California Paycheck Calculator 2026 | Take-Home Pay After Taxes",
    description:
      "Calculate your California take-home pay for 2026. Includes state income tax, SDI, and mental health services tax. Free, instant results for any salary.",
  },
  hasIncomeTax: true,

  // Source: 2025 California Tax Rate Schedules (FTB Schedules X/Y/Z, ftb.ca.gov).
  // Latest official figures as of July 2026; FTB publishes 2026 indexed brackets in late 2026.
  // MUST stay in sync with src/lib/tax/states/california.ts.
  brackets: {
    single: [
      { rate: 0.01, min: 0, max: 11079 },
      { rate: 0.02, min: 11079, max: 26264 },
      { rate: 0.04, min: 26264, max: 41452 },
      { rate: 0.06, min: 41452, max: 57542 },
      { rate: 0.08, min: 57542, max: 72724 },
      { rate: 0.093, min: 72724, max: 371479 },
      { rate: 0.103, min: 371479, max: 445771 },
      { rate: 0.113, min: 445771, max: 742953 },
      { rate: 0.123, min: 742953, max: null },
    ],
    married_filing_jointly: [
      { rate: 0.01, min: 0, max: 22158 },
      { rate: 0.02, min: 22158, max: 52528 },
      { rate: 0.04, min: 52528, max: 82904 },
      { rate: 0.06, min: 82904, max: 115084 },
      { rate: 0.08, min: 115084, max: 145448 },
      { rate: 0.093, min: 145448, max: 742958 },
      { rate: 0.103, min: 742958, max: 891542 },
      { rate: 0.113, min: 891542, max: 1485906 },
      { rate: 0.123, min: 1485906, max: null },
    ],
    head_of_household: [
      { rate: 0.01, min: 0, max: 22173 },
      { rate: 0.02, min: 22173, max: 52530 },
      { rate: 0.04, min: 52530, max: 67716 },
      { rate: 0.06, min: 67716, max: 83805 },
      { rate: 0.08, min: 83805, max: 98990 },
      { rate: 0.093, min: 98990, max: 505208 },
      { rate: 0.103, min: 505208, max: 606251 },
      { rate: 0.113, min: 606251, max: 1010417 },
      { rate: 0.123, min: 1010417, max: null },
    ],
  },

  standardDeduction: {
    single: 5706, // FTB 2025 (latest official)
    married_filing_jointly: 11412, // FTB 2025
    head_of_household: 11412, // FTB 2025 — CA HOH equals MFJ, unlike federal
  },

  settings: {
    sdiRate: 0.013, // 1.3% for 2026 (EDD). No wage cap since Jan 1, 2024 (SB 951).
    mentalHealthRate: 0.01, // 1% on taxable income over $1M (Prop 63)
    mentalHealthThreshold: 1000000, // Statutory, not indexed
  },

  faq: [
    {
      question: "What is California SDI and is it required?",
      answer:
        "California State Disability Insurance (SDI) is a mandatory payroll deduction for most employees, administered by the Employment Development Department (EDD). The SDI program funds short-term disability benefits and Paid Family Leave. For 2026, the SDI withholding rate is 1.3% and it applies to ALL wages — Senate Bill 951 permanently removed the taxable wage cap starting January 1, 2024, so there is no maximum annual SDI deduction. Most California workers cannot opt out unless their employer has a state-approved voluntary plan.",
    },
    {
      question: "What is the California Mental Health Services Tax?",
      answer:
        "The Mental Health Services Tax (MHST) is a 1% surtax on California taxable income exceeding $1 million for single filers or $2 million for married filing jointly. It was enacted through Proposition 63 (2004) and is sometimes called the \"millionaire's tax.\" The revenue funds mental health programs across the state. For example, if you have $1.5 million in California taxable income as a single filer, you would pay an additional 1% (or $5,000) on the $500,000 above the threshold.",
    },
    {
      question: "Does California have the highest state income tax in the country?",
      answer:
        "California has the highest top marginal state income tax rate in the nation at 12.3% (13.3% including the 1% Mental Health Services Tax on income over $1 million), which applies to taxable income over $742,953 for single filers (2025 FTB schedule). Hawaii's top rate of 11% and New York's top rate of 10.9% are also among the highest. However, California's tax brackets are progressive, so lower and middle-income earners pay significantly less. The effective tax rate for most Californians is much lower than the top marginal rate suggests, especially after accounting for the standard deduction.",
    },
    {
      question: "How does California's standard deduction compare to the federal standard deduction?",
      answer:
        "California's standard deduction is considerably smaller than the federal one. California allows $5,706 for single filers and $11,412 for married filing jointly (2025 FTB figures, the latest official amounts), while the 2026 federal standard deduction is $16,100 and $32,200 respectively. This difference means a larger portion of your income is subject to California state tax compared to federal tax. Some taxpayers benefit from itemizing deductions on their California return if their itemized deductions exceed the state standard deduction, even if they take the standard deduction federally.",
    },
    {
      question: "Are California payroll taxes different for non-residents working in California?",
      answer:
        "Yes, non-residents who earn income in California are generally subject to California state income tax on that income. California taxes all income sourced within the state, regardless of where you live. However, non-residents may be able to claim a credit on their home state return for taxes paid to California. If you live in a state with no income tax (like Nevada) but work in California, you will still pay California income tax on wages earned there, though you won't owe additional tax to your home state.",
    },
    {
      question: "What additional deductions are available on California state tax returns?",
      answer:
        "California offers several deductions and credits that can reduce your state tax liability. Common ones include the renter's credit (up to $60 for single filers with income under certain limits), college access tax credit, and credits for child and dependent care expenses. California does not conform to all federal deductions — for example, it does not allow the federal deduction for state and local taxes (SALT). California also has its own rules for retirement contributions and HSA deductions that may differ from federal treatment.",
    },
  ],

  neighboringStates: ["nevada", "arizona", "oregon"],
};